import Zigzag.Goal
